from django.contrib import admin

from .models import Mortgage

# Register your models here.
admin.site.register(Mortgage)
